using System;
using System.Windows.Forms;

namespace GUI_IkkiSonYigindisi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnHisobla_Click(object sender, EventArgs e)
        {
            try
            {
                double son1 = Convert.ToDouble(txtSon1.Text);
                double son2 = Convert.ToDouble(txtSon2.Text);
                double yigindi = son1 + son2;
                lblNatija.Text = "Yig'indisi: " + yigindi.ToString();
            }
            catch
            {
                MessageBox.Show("Iltimos, to‘g‘ri son kiriting!", "Xatolik", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
