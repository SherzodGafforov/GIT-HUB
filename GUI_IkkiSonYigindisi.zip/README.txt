# GUI Ikki Son Yig'indisi

Ushbu Visual Studio Windows Forms dasturida foydalanuvchi ikkita son kiritib, ularning yig'indisini ko'rishi mumkin.
